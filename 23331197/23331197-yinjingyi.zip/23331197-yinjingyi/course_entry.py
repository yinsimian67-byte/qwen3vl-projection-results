"""Course entry points for training, loading, and exporting the language model."""
from __future__ import annotations

import argparse
import csv
import json
import math
import random
import shutil
import sys
import time
from pathlib import Path

import numpy as np
import torch

from basics.data import evaluate_nll
from basics.model import build_model
from basics.optim import AdamW
from basics.training import set_seed, train_update
from course_tools.contracts import (MAX_WEIGHTS_BYTES, checked_budget, normalize_model,
                                   track_rules, validate_v2_run, validate_weights, write_json)

CSV_FIELDS = ("event", "step", "train_tokens", "train_loss", "valid_nll", "valid_ppl", "lr", "elapsed_seconds")


def _rules_for_run(config: dict) -> dict:
    if config.get("mode") == "ranked":
        return validate_v2_run(config)
    if config.get("mode") not in {"experiment", "smoke"}:
        raise ValueError("mode 必须为 ranked、experiment 或 smoke")
    model = normalize_model(config["model"], course=config.get("mode") != "smoke")
    quantum, total_steps = checked_budget(config)
    if config.get("mode") == "experiment":
        rules = track_rules(config.get("track"))
        if config["token_budget"] != rules["token_budget"]:
            raise ValueError("experiment 也必须使用本课程规定的训练 token 预算")
    return {"model": model, "quantum": quantum, "total_steps": total_steps}


def _capture_rng() -> dict:
    state = {"python": random.getstate(), "numpy": np.random.get_state(), "torch": torch.get_rng_state()}
    if torch.cuda.is_available():
        state["cuda"] = torch.cuda.get_rng_state_all()
    return state


def _restore_rng(state: dict) -> None:
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"])
    if "cuda" in state and torch.cuda.is_available():
        torch.cuda.set_rng_state_all(state["cuda"])


def _checkpoint_payload(model, optimizer, scaler, config: dict, *, step: int, train_tokens: int,
                        best_nll: float, elapsed_seconds: float) -> dict:
    return {"format_version": 2, "model_state_dict": model.state_dict(),
            "optimizer_state_dict": optimizer.state_dict(),
            "scaler_state_dict": None if scaler is None else scaler.state_dict(), "config": config,
            "step": step, "train_tokens": train_tokens, "best_nll": best_nll,
            "elapsed_seconds": elapsed_seconds, "rng_state": _capture_rng(),
            "environment": {"python": sys.version, "torch": torch.__version__,
                            "numpy": np.__version__, "cuda": torch.version.cuda}}


def _save_checkpoint(path: Path, model, optimizer, scaler, config, **progress) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(_checkpoint_payload(model, optimizer, scaler, config, **progress), path)


def _state_dict_from_loaded(value: object) -> dict[str, torch.Tensor]:
    if isinstance(value, dict) and value and all(isinstance(t, torch.Tensor) for t in value.values()):
        return value
    if isinstance(value, dict):
        for key in ("model_state_dict", "model_state", "state_dict"):
            state = value.get(key)
            if isinstance(state, dict) and all(isinstance(t, torch.Tensor) for t in state.values()):
                return state
    raise ValueError("checkpoint 不含可加载的模型 state_dict")


def _read_checkpoint(path: str | Path, *, device="cpu") -> tuple[dict[str, torch.Tensor], dict | None]:
    value = torch.load(path, map_location=device, weights_only=False)
    return _state_dict_from_loaded(value), value if isinstance(value, dict) and "model_state_dict" in value else None


def _validate_public_nll(model, tokens: np.ndarray, config: dict, device: torch.device) -> float:
    old_matmul = old_cudnn = None
    if device.type == "cuda":
        old_matmul, old_cudnn = torch.backends.cuda.matmul.allow_tf32, torch.backends.cudnn.allow_tf32
        torch.backends.cuda.matmul.allow_tf32 = torch.backends.cudnn.allow_tf32 = False
    try:
        with torch.autocast(device_type=device.type, enabled=False):
            return evaluate_nll(model.float(), tokens, config["model"]["context_length"], config["eval_batch_size"], device)
    finally:
        if device.type == "cuda":
            torch.backends.cuda.matmul.allow_tf32, torch.backends.cudnn.allow_tf32 = old_matmul, old_cudnn


def train(config: dict, run_dir: str, resume: str | None = None):
    """Train or resume a run, recording every update and full public validations."""
    config = json.loads(json.dumps(config))
    rules = _rules_for_run(config)
    config["model"] = rules["model"]
    output = Path(run_dir)
    output.mkdir(parents=True, exist_ok=True)
    device = torch.device(config.get("device", "cuda"))
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("配置要求 CUDA，但当前 PyTorch 没有可用 CUDA 设备")
    if device.type == "cpu" and config.get("precision") != "fp32":
        raise ValueError("CPU 训练只支持 precision=fp32")
    train_data = np.load(config["train_data"], mmap_mode="r", allow_pickle=False)
    valid_data = np.load(config["valid_data"], mmap_mode="r", allow_pickle=False)
    if train_data.ndim != 1 or valid_data.ndim != 1:
        raise ValueError("训练和验证数据必须是一维 token 流")

    # Seed before constructing the model: its parameter initialization is part
    # of the reproducible training state.
    if resume is None:
        set_seed(config["seed"])
    model = build_model(config, device=device)
    optimizer = AdamW(model.parameters(), lr=config["learning_rate"], betas=tuple(config["betas"]),
                      eps=config["eps"], weight_decay=config["weight_decay"])
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda" and config["precision"] == "fp16")
    scaler_or_none = scaler if scaler.is_enabled() else None
    step = train_tokens = 0
    best_nll, prior_elapsed = math.inf, 0.0
    metrics_path = output / "metrics.csv"

    if resume is None:
        write_json(output / "config.json", config)
    else:
        state, checkpoint = _read_checkpoint(resume, device=device)
        if checkpoint is None:
            raise ValueError("恢复训练必须使用完整 checkpoint，而不是导出的纯评分权重")
        if checkpoint.get("config", {}).get("model") != config["model"]:
            raise ValueError("恢复 checkpoint 的模型结构与当前 config 不一致")
        model.load_state_dict(state)
        optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        if scaler_or_none is not None and checkpoint.get("scaler_state_dict") is not None:
            scaler_or_none.load_state_dict(checkpoint["scaler_state_dict"])
        step, train_tokens = int(checkpoint["step"]), int(checkpoint["train_tokens"])
        best_nll, prior_elapsed = float(checkpoint["best_nll"]), float(checkpoint["elapsed_seconds"])
        _restore_rng(checkpoint["rng_state"])
        if not metrics_path.exists():
            old_metrics = Path(resume).parent / "metrics.csv"
            if old_metrics.exists():
                shutil.copy2(old_metrics, metrics_path)
        write_json(output / "config.json", config)

    new_file = not metrics_path.exists() or metrics_path.stat().st_size == 0
    started = time.monotonic()
    with metrics_path.open("a", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=CSV_FIELDS)
        if new_file:
            writer.writeheader()
        def elapsed() -> float:
            return prior_elapsed + time.monotonic() - started
        def record(event: str, *, loss=None, nll=None, lr=0.0) -> None:
            writer.writerow({"event": event, "step": step, "train_tokens": train_tokens,
                             "train_loss": "" if loss is None else repr(loss),
                             "valid_nll": "" if nll is None else repr(nll),
                             "valid_ppl": "" if nll is None else repr(math.exp(nll)),
                             "lr": repr(lr), "elapsed_seconds": repr(elapsed())})
            stream.flush()
        if resume is None:
            _save_checkpoint(output / "checkpoint_000.pt", model, optimizer, scaler_or_none, config,
                             step=step, train_tokens=train_tokens, best_nll=best_nll, elapsed_seconds=elapsed())
        while step < rules["total_steps"]:
            loss, lr = train_update(model, optimizer, train_data, config, step, scaler=scaler_or_none)
            step += 1
            train_tokens = step * rules["quantum"]
            record("train", loss=loss, lr=lr)
            if train_tokens % config["validate_every"] == 0:
                nll = _validate_public_nll(model, valid_data, config, device)
                record("valid", nll=nll, lr=lr)
                if nll < best_nll:
                    best_nll = nll
                    _save_checkpoint(output / "best.pt", model, optimizer, scaler_or_none, config,
                                     step=step, train_tokens=train_tokens, best_nll=best_nll, elapsed_seconds=elapsed())
            if train_tokens in config["milestones"]:
                percentage = 100 * train_tokens // config["token_budget"]
                _save_checkpoint(output / f"checkpoint_{percentage:03d}.pt", model, optimizer, scaler_or_none, config,
                                 step=step, train_tokens=train_tokens, best_nll=best_nll, elapsed_seconds=elapsed())
    return {"run_dir": str(output), "step": step, "train_tokens": train_tokens, "best_nll": best_nll}


def load_model(checkpoint: str, config: dict):
    """Load either a pure exported state dict or one of this module's full checkpoints."""
    model = build_model(normalize_model(config.get("model", config), course=False), device="cpu")
    state, _ = _read_checkpoint(checkpoint, device="cpu")
    model.load_state_dict(state, strict=True)
    return model


def export(checkpoint: str, output: str):
    """Write an independent CPU FP32 state dict without optimizer metadata."""
    state, metadata = _read_checkpoint(checkpoint, device="cpu")
    clean = {key: tensor.detach().cpu().float().contiguous().clone() for key, tensor in state.items()}
    if metadata is not None and isinstance(metadata.get("config"), dict):
        validate_weights(clean, metadata["config"]["model"])
    destination = Path(output)
    destination.parent.mkdir(parents=True, exist_ok=True)
    torch.save(clean, destination)
    if destination.stat().st_size > MAX_WEIGHTS_BYTES:
        destination.unlink()
        raise ValueError("导出的评分权重超过 240 MB")
    return str(destination)


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="action", required=True)
    training = sub.add_parser("train")
    training.add_argument("--config", required=True)
    training.add_argument("--run-dir", required=True)
    training.add_argument("--resume")
    exporting = sub.add_parser("export")
    exporting.add_argument("--checkpoint", required=True)
    exporting.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.action == "train":
        train(json.loads(Path(args.config).read_text(encoding="utf-8")), args.run_dir, args.resume)
    else:
        export(args.checkpoint, args.output)


if __name__ == "__main__":
    main()

