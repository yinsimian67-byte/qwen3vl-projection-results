import importlib.metadata

from .bpe import train_bpe
from .data import evaluate_nll, get_batch
from .model import (MultiHeadSelfAttention, TransformerBlock, TransformerLM,
                    apply_rope, build_model, scaled_dot_product_attention)
from .nn import (Embedding, Linear, RMSNorm, SiLUFeedForward, SwiGLU,
                 clip_grad_norm_, cross_entropy, silu, softmax)
from .optim import AdamW, get_lr_cosine_schedule
from .serialization import load_checkpoint, save_checkpoint
from .tokenizer import BPETokenizer, load_course_tokenizer
from .training import set_seed, train_update

try:
    __version__ = importlib.metadata.version("cs336_basics")
except importlib.metadata.PackageNotFoundError:
    pass

