"""Neural-network building blocks used by the course Transformer."""
from __future__ import annotations

import math

import torch
from torch import Tensor, nn
import torch.nn.functional as F


class Linear(nn.Module):
    """Bias-free linear layer (the course architecture has no biases)."""

    def __init__(self, d_in: int, d_out: int, *, device=None, dtype=None):
        super().__init__()
        self.weight = nn.Parameter(torch.empty(d_out, d_in, device=device, dtype=dtype))
        nn.init.trunc_normal_(self.weight, std=0.02)

    def forward(self, x: Tensor) -> Tensor:
        return F.linear(x, self.weight)


class Embedding(nn.Module):
    def __init__(self, vocab_size: int, d_model: int, *, device=None, dtype=None):
        super().__init__()
        self.weight = nn.Parameter(torch.empty(vocab_size, d_model, device=device, dtype=dtype))
        nn.init.trunc_normal_(self.weight, std=0.02)

    def forward(self, token_ids: Tensor) -> Tensor:
        return F.embedding(token_ids, self.weight)


class RMSNorm(nn.Module):
    def __init__(self, d_model: int, eps: float = 1e-5, *, device=None, dtype=None):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(d_model, device=device, dtype=dtype))

    def forward(self, x: Tensor) -> Tensor:
        # Keep the reduction in the input dtype to match the reference component tests.
        inv_rms = torch.rsqrt(x.square().mean(dim=-1, keepdim=True) + self.eps)
        return x * inv_rms * self.weight


def silu(x: Tensor) -> Tensor:
    return x * torch.sigmoid(x)


class SwiGLU(nn.Module):
    def __init__(self, d_model: int, d_ff: int, *, device=None, dtype=None):
        super().__init__()
        self.w1 = Linear(d_model, d_ff, device=device, dtype=dtype)
        self.w2 = Linear(d_ff, d_model, device=device, dtype=dtype)
        self.w3 = Linear(d_model, d_ff, device=device, dtype=dtype)

    def forward(self, x: Tensor) -> Tensor:
        return self.w2(silu(self.w1(x)) * self.w3(x))


class SiLUFeedForward(nn.Module):
    def __init__(self, d_model: int, d_ff: int, *, device=None, dtype=None):
        super().__init__()
        self.w1 = Linear(d_model, d_ff, device=device, dtype=dtype)
        self.w2 = Linear(d_ff, d_model, device=device, dtype=dtype)

    def forward(self, x: Tensor) -> Tensor:
        return self.w2(silu(self.w1(x)))


def softmax(x: Tensor, dim: int = -1) -> Tensor:
    """Numerically stable softmax."""
    shifted = x - x.amax(dim=dim, keepdim=True)
    exps = shifted.exp()
    return exps / exps.sum(dim=dim, keepdim=True)


def cross_entropy(logits: Tensor, targets: Tensor) -> Tensor:
    """Mean negative log-likelihood for flattened language-model targets."""
    log_probs = logits - torch.logsumexp(logits, dim=-1, keepdim=True)
    return -log_probs.gather(-1, targets.long().unsqueeze(-1)).squeeze(-1).mean()


def clip_grad_norm_(parameters, max_l2_norm: float) -> Tensor:
    """Clip all existing parameter gradients in place and return their original norm."""
    grads = [p.grad for p in parameters if p.grad is not None]
    if not grads:
        return torch.zeros(())
    total = torch.linalg.vector_norm(torch.stack([torch.linalg.vector_norm(g.detach()) for g in grads]))
    scale = max_l2_norm / (total + 1e-6)
    if scale < 1:
        for grad in grads:
            grad.mul_(scale)
    return total

