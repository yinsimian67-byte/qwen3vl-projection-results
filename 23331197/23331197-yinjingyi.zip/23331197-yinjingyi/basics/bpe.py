"""Training for the byte-level BPE used in the tokenizer exercise."""
from __future__ import annotations

from collections import Counter
from pathlib import Path

import regex

from .tokenizer import GPT2_PATTERN


def train_bpe(input_path: str | Path, vocab_size: int, special_tokens: list[str], **_kwargs):
    """Train deterministic byte BPE; ties use lexicographically largest pair as in CS336."""
    if vocab_size < 256 + len(special_tokens):
        raise ValueError("vocab_size is too small for bytes and special tokens")
    text = Path(input_path).read_text(encoding="utf-8")
    # Special strings are excluded before pre-tokenization, so no learned token can span them.
    splitter = regex.compile("|".join(regex.escape(s) for s in sorted(special_tokens, key=len, reverse=True))) if special_tokens else None
    counts: Counter[tuple[bytes, ...]] = Counter()
    pattern = regex.compile(GPT2_PATTERN)
    cursor = 0
    for special in (splitter.finditer(text) if splitter else []):
        for match in pattern.finditer(text[cursor:special.start()]):
            counts[tuple(bytes([x]) for x in match.group().encode("utf-8"))] += 1
        cursor = special.end()
    for match in pattern.finditer(text[cursor:]):
        counts[tuple(bytes([x]) for x in match.group().encode("utf-8"))] += 1

    vocab = {i: bytes([i]) for i in range(256)}
    for special in special_tokens:
        vocab[len(vocab)] = special.encode("utf-8")
    merges: list[tuple[bytes, bytes]] = []

    # Maintain global pair frequencies incrementally.  Recounting every pair
    # in every word after each merge is correct but too slow for the exercise's
    # speed test.
    pair_counts: Counter[tuple[bytes, bytes]] = Counter()
    for word, frequency in counts.items():
        for pair, occurrences in Counter(zip(word, word[1:])).items():
            pair_counts[pair] += occurrences * frequency

    while len(vocab) < vocab_size:
        if not pair_counts:
            break
        best = max(pair_counts, key=lambda pair: (pair_counts[pair], pair))
        merged = best[0] + best[1]
        merges.append(best)
        vocab[len(vocab)] = merged
        for word, frequency in list(counts.items()):
            if best not in zip(word, word[1:]):
                continue
            old_pairs = Counter(zip(word, word[1:]))
            new_word: list[bytes] = []
            index = 0
            while index < len(word):
                if index + 1 < len(word) and (word[index], word[index + 1]) == best:
                    new_word.append(merged)
                    index += 2
                else:
                    new_word.append(word[index])
                    index += 1
            new_word_tuple = tuple(new_word)
            del counts[word]
            counts[new_word_tuple] += frequency
            for pair, occurrences in old_pairs.items():
                pair_counts[pair] -= occurrences * frequency
                if pair_counts[pair] == 0:
                    del pair_counts[pair]
            for pair, occurrences in Counter(zip(new_word_tuple, new_word_tuple[1:])).items():
                pair_counts[pair] += occurrences * frequency
    return vocab, merges

