"""Small, testable checkpoint helpers. Full run checkpoints are built by course_entry."""
from __future__ import annotations

import os
from typing import BinaryIO, IO

import torch


def save_checkpoint(model: torch.nn.Module, optimizer: torch.optim.Optimizer, iteration: int,
                    out: str | os.PathLike | BinaryIO | IO[bytes]) -> None:
    torch.save({"model_state_dict": model.state_dict(), "optimizer_state_dict": optimizer.state_dict(),
                "iteration": iteration}, out)


def load_checkpoint(src: str | os.PathLike | BinaryIO | IO[bytes], model: torch.nn.Module,
                    optimizer: torch.optim.Optimizer) -> int:
    state = torch.load(src, map_location="cpu", weights_only=False)
    model.load_state_dict(state["model_state_dict"])
    optimizer.load_state_dict(state["optimizer_state_dict"])
    return int(state["iteration"])

