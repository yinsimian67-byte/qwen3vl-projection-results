"""Reusable training primitives; run-directory policy belongs in ``course_entry``."""
from __future__ import annotations

import random

import numpy as np
import torch
import torch.nn.functional as F

from .data import get_batch
from .nn import clip_grad_norm_
from .optim import get_lr_cosine_schedule


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def autocast_context(device: torch.device, precision: str):
    if device.type != "cuda" or precision == "fp32":
        return torch.autocast(device_type=device.type, enabled=False)
    dtype = torch.bfloat16 if precision == "bf16" else torch.float16
    return torch.autocast(device_type="cuda", dtype=dtype)


def train_update(model, optimizer, tokens: np.ndarray, config: dict, step: int, *, scaler=None) -> tuple[float, float]:
    """Perform exactly one effective-batch update and return (mean_nll, lr)."""
    device = next(model.parameters()).device
    accumulation = config["gradient_accumulation"]
    context = config["model"]["context_length"]
    lr = get_lr_cosine_schedule(step, config["learning_rate"], config["min_learning_rate"],
                                config["warmup_steps"], config["token_budget"] //
                                (config["micro_batch_size"] * accumulation * context))
    for group in optimizer.param_groups:
        group["lr"] = lr
    optimizer.zero_grad(set_to_none=True)
    weighted_loss = 0.0
    for _ in range(accumulation):
        x, y = get_batch(tokens, config["micro_batch_size"], context, device)
        with autocast_context(device, config["precision"]):
            logits = model(x)
            loss = F.cross_entropy(logits.reshape(-1, logits.shape[-1]), y.reshape(-1))
            loss = loss / accumulation
        weighted_loss += loss.detach().float().item()
        if scaler is None:
            loss.backward()
        else:
            scaler.scale(loss).backward()
    if scaler is not None:
        scaler.unscale_(optimizer)
    clip_grad_norm_(model.parameters(), config["grad_clip"])
    if scaler is None:
        optimizer.step()
    else:
        scaler.step(optimizer)
        scaler.update()
    return weighted_loss, lr

