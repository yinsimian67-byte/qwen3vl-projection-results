"""Autoregressive greedy and temperature/top-p generation."""
from __future__ import annotations

import torch


@torch.no_grad()
def generate(model, token_ids: list[int], max_new_tokens: int, *, temperature: float = 0.0,
             top_p: float = 1.0, generator: torch.Generator | None = None) -> list[int]:
    ids = list(token_ids)
    device = next(model.parameters()).device
    for _ in range(max_new_tokens):
        context = torch.tensor(ids[-model.context_length:], dtype=torch.long, device=device).unsqueeze(0)
        logits = model(context)[0, -1].float()
        if temperature <= 0:
            next_id = int(logits.argmax())
        else:
            probs = torch.softmax(logits / temperature, dim=-1)
            if top_p < 1:
                values, indices = probs.sort(descending=True)
                keep = values.cumsum(0) <= top_p
                keep[0] = True
                filtered = torch.zeros_like(probs).scatter(0, indices[keep], values[keep])
                probs = filtered / filtered.sum()
            next_id = int(torch.multinomial(probs, 1, generator=generator))
        ids.append(next_id)
    return ids

