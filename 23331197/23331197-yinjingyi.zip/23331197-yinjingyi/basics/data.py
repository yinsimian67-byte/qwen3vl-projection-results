"""Token-stream batching and exact full-validation helpers."""
from __future__ import annotations

import numpy as np
import torch
from torch import Tensor


def get_batch(dataset: np.ndarray, batch_size: int, context_length: int, device: str | torch.device) -> tuple[Tensor, Tensor]:
    if dataset.ndim != 1 or len(dataset) <= context_length:
        raise ValueError("dataset must be a one-dimensional token stream longer than context_length")
    starts = torch.randint(0, len(dataset) - context_length, (batch_size,))
    offsets = torch.arange(context_length)
    indices = starts[:, None] + offsets[None, :]
    # Indexing through NumPy makes this work for normal ndarrays and memory maps.
    x = torch.from_numpy(np.asarray(dataset[indices.numpy()], dtype=np.int64))
    y = torch.from_numpy(np.asarray(dataset[(indices + 1).numpy()], dtype=np.int64))
    return x.to(device), y.to(device)


@torch.no_grad()
def evaluate_nll(model, tokens: np.ndarray, context_length: int, batch_size: int, device) -> float:
    """Exact NLL over every adjacent target token in the fixed validation stream."""
    was_training = model.training
    model.eval()
    total_loss, total_targets = 0.0, 0
    for start in range(0, len(tokens) - 1, context_length):
        # A window is at most context+1 long so all its next-token targets fit.
        window = np.asarray(tokens[start : min(len(tokens), start + context_length + 1)], dtype=np.int64)
        if len(window) < 2:
            continue
        x = torch.from_numpy(window[:-1]).unsqueeze(0).to(device)
        y = torch.from_numpy(window[1:]).to(device)
        logits = model(x).float().reshape(-1, model.lm_head.weight.shape[0])
        total_loss += torch.nn.functional.cross_entropy(logits, y, reduction="sum").item()
        total_targets += y.numel()
    model.train(was_training)
    return total_loss / total_targets

