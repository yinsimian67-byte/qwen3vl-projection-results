"""Optimizer and learning-rate schedule."""
from __future__ import annotations

import math

import torch


AdamW = torch.optim.AdamW


def get_lr_cosine_schedule(it: int, max_learning_rate: float, min_learning_rate: float,
                           warmup_iters: int, cosine_cycle_iters: int) -> float:
    if it < warmup_iters:
        return max_learning_rate * it / warmup_iters if warmup_iters else max_learning_rate
    if it >= cosine_cycle_iters:
        return min_learning_rate
    ratio = (it - warmup_iters) / (cosine_cycle_iters - warmup_iters)
    return min_learning_rate + 0.5 * (1 + math.cos(math.pi * ratio)) * (max_learning_rate - min_learning_rate)

