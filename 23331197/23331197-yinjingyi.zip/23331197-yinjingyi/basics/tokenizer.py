"""Byte-level BPE tokenizer compatible with the course tokenizer files."""
from __future__ import annotations

import base64
import json
from pathlib import Path
from typing import Iterable, Iterator

import regex


GPT2_PATTERN = r"'(?:[sdmt]|ll|ve|re)| ?\p{L}+| ?\p{N}+| ?[^\s\p{L}\p{N}]+|\s+(?!\S)|\s+"


class BPETokenizer:
    def __init__(self, vocab: dict[int, bytes], merges: list[tuple[bytes, bytes]],
                 special_tokens: list[str] | None = None, pattern: str = GPT2_PATTERN):
        self.vocab = dict(vocab)
        self.id_for_bytes = {value: key for key, value in self.vocab.items()}
        if len(self.id_for_bytes) != len(self.vocab):
            raise ValueError("vocabulary byte strings must be unique")
        self.merge_ranks = {pair: rank for rank, pair in enumerate(merges)}
        self.special_to_id = {token: self.id_for_bytes[token.encode("utf-8")] for token in (special_tokens or [])}
        self.pattern = regex.compile(pattern)
        # Longest first makes overlapping special tokens deterministic.
        self._special_splitter = regex.compile("(" + "|".join(regex.escape(s) for s in sorted(self.special_to_id, key=len, reverse=True)) + ")") if self.special_to_id else None

    def _encode_piece(self, text: str) -> list[int]:
        symbols = list(text.encode("utf-8"))
        pieces = [bytes([b]) for b in symbols]
        while len(pieces) > 1:
            ranked = [(self.merge_ranks[pair], i) for i, pair in enumerate(zip(pieces, pieces[1:])) if pair in self.merge_ranks]
            if not ranked:
                break
            _, i = min(ranked)
            pieces[i : i + 2] = [pieces[i] + pieces[i + 1]]
        try:
            return [self.id_for_bytes[piece] for piece in pieces]
        except KeyError as exc:
            raise ValueError("vocabulary does not contain a required byte token") from exc

    def encode(self, text: str) -> list[int]:
        parts = self._special_splitter.split(text) if self._special_splitter else [text]
        ids: list[int] = []
        for part in parts:
            if not part:
                continue
            if part in self.special_to_id:
                ids.append(self.special_to_id[part])
            else:
                for match in self.pattern.finditer(part):
                    ids.extend(self._encode_piece(match.group()))
        return ids

    def encode_iterable(self, iterable: Iterable[str]) -> Iterator[int]:
        # A line at a time is bounded-memory and preserves all common text-file inputs.
        for chunk in iterable:
            yield from self.encode(chunk)

    def decode(self, token_ids: Iterable[int]) -> str:
        return b"".join(self.vocab[int(token_id)] for token_id in token_ids).decode("utf-8", errors="replace")


def load_course_tokenizer(directory: str | Path) -> BPETokenizer:
    directory = Path(directory)
    meta = json.loads((directory / "tokenizer.json").read_text(encoding="utf-8"))
    raw_vocab = json.loads((directory / "vocab.json").read_text(encoding="utf-8"))
    raw_merges = json.loads((directory / "merges.json").read_text(encoding="utf-8"))
    vocab = {int(key): base64.b64decode(value) for key, value in raw_vocab.items()}
    merges = [(base64.b64decode(a), base64.b64decode(b)) for a, b in raw_merges]
    return BPETokenizer(vocab, merges, meta.get("special_tokens"), meta.get("pattern", GPT2_PATTERN))

