"""Bias-free causal Transformer language model used by the low track."""
from __future__ import annotations

import math

import torch
from torch import Tensor, nn

from .nn import Embedding, Linear, RMSNorm, SiLUFeedForward, SwiGLU, softmax


def apply_rope(x: Tensor, token_positions: Tensor, theta: float = 10000.0) -> Tensor:
    """Apply RoPE to adjacent even/odd coordinates of ``[..., T, d]``."""
    d = x.shape[-1]
    if d % 2:
        raise ValueError("RoPE dimension must be even")
    positions = token_positions.to(device=x.device, dtype=torch.float32)
    inv_freq = theta ** (-torch.arange(0, d, 2, device=x.device, dtype=torch.float32) / d)
    angles = positions.unsqueeze(-1) * inv_freq
    cos, sin = angles.cos().to(x.dtype), angles.sin().to(x.dtype)
    # ``positions`` normally has shape [B, T], while attention inputs have
    # [B, H, T, d]; insert the head axis when needed.
    while cos.ndim < x.ndim:
        cos, sin = cos.unsqueeze(-3), sin.unsqueeze(-3)
    even, odd = x[..., 0::2], x[..., 1::2]
    return torch.stack((even * cos - odd * sin, even * sin + odd * cos), dim=-1).flatten(-2)


def scaled_dot_product_attention(q: Tensor, k: Tensor, v: Tensor, mask: Tensor | None = None) -> Tensor:
    scores = q @ k.transpose(-2, -1) / math.sqrt(q.shape[-1])
    if mask is not None:
        scores = scores.masked_fill(~mask.to(torch.bool), float("-inf"))
    return softmax(scores, dim=-1) @ v


class MultiHeadSelfAttention(nn.Module):
    def __init__(self, d_model: int, num_heads: int, *, rope_theta: float = 10000.0,
                 use_rope: bool = True, device=None, dtype=None):
        super().__init__()
        if d_model % num_heads:
            raise ValueError("d_model must be divisible by num_heads")
        self.num_heads = num_heads
        self.head_dim = d_model // num_heads
        self.rope_theta, self.use_rope = rope_theta, use_rope
        self.q_proj = Linear(d_model, d_model, device=device, dtype=dtype)
        self.k_proj = Linear(d_model, d_model, device=device, dtype=dtype)
        self.v_proj = Linear(d_model, d_model, device=device, dtype=dtype)
        self.output_proj = Linear(d_model, d_model, device=device, dtype=dtype)

    def forward(self, x: Tensor, token_positions: Tensor | None = None) -> Tensor:
        b, t, d = x.shape
        def heads(projected: Tensor) -> Tensor:
            return projected.view(b, t, self.num_heads, self.head_dim).transpose(1, 2)
        q, k, v = heads(self.q_proj(x)), heads(self.k_proj(x)), heads(self.v_proj(x))
        if self.use_rope:
            if token_positions is None:
                token_positions = torch.arange(t, device=x.device).unsqueeze(0)
            q, k = apply_rope(q, token_positions, self.rope_theta), apply_rope(k, token_positions, self.rope_theta)
        causal = torch.ones(t, t, dtype=torch.bool, device=x.device).tril()
        output = scaled_dot_product_attention(q, k, v, causal)
        output = output.transpose(1, 2).contiguous().view(b, t, d)
        return self.output_proj(output)


class TransformerBlock(nn.Module):
    def __init__(self, d_model: int, num_heads: int, d_ff: int, *, rope_theta: float = 10000.0,
                 norm: str = "pre", position: str = "rope", ffn: str = "swiglu", device=None, dtype=None):
        super().__init__()
        self.norm_kind = norm
        self.attn = MultiHeadSelfAttention(d_model, num_heads, rope_theta=rope_theta,
                                           use_rope=position == "rope", device=device, dtype=dtype)
        self.ffn = SwiGLU(d_model, d_ff, device=device, dtype=dtype) if ffn == "swiglu" else SiLUFeedForward(d_model, d_ff, device=device, dtype=dtype)
        if norm != "none":
            self.ln1, self.ln2 = RMSNorm(d_model, device=device, dtype=dtype), RMSNorm(d_model, device=device, dtype=dtype)

    def forward(self, x: Tensor, token_positions: Tensor | None = None) -> Tensor:
        if self.norm_kind == "pre":
            x = x + self.attn(self.ln1(x), token_positions)
            return x + self.ffn(self.ln2(x))
        if self.norm_kind == "post":
            x = self.ln1(x + self.attn(x, token_positions))
            return self.ln2(x + self.ffn(x))
        x = x + self.attn(x, token_positions)
        return x + self.ffn(x)


class TransformerLM(nn.Module):
    def __init__(self, *, vocab_size: int, context_length: int, d_model: int, num_layers: int,
                 num_heads: int, d_ff: int, rope_theta: float = 10000.0, norm: str = "pre",
                 position: str = "rope", ffn: str = "swiglu", device=None, dtype=None):
        super().__init__()
        self.context_length = context_length
        self.token_embeddings = Embedding(vocab_size, d_model, device=device, dtype=dtype)
        self.layers = nn.ModuleList([TransformerBlock(d_model, num_heads, d_ff, rope_theta=rope_theta,
                                    norm=norm, position=position, ffn=ffn, device=device, dtype=dtype)
                                    for _ in range(num_layers)])
        self.norm_kind = norm
        if norm != "none":
            self.ln_final = RMSNorm(d_model, device=device, dtype=dtype)
        self.lm_head = Linear(d_model, vocab_size, device=device, dtype=dtype)

    def forward(self, token_ids: Tensor) -> Tensor:
        if token_ids.ndim != 2:
            raise ValueError("token_ids must have shape [batch, time]")
        if token_ids.shape[1] > self.context_length:
            raise ValueError("input is longer than the configured context length")
        x = self.token_embeddings(token_ids)
        positions = torch.arange(token_ids.shape[1], device=token_ids.device).unsqueeze(0)
        for layer in self.layers:
            x = layer(x, positions)
        if self.norm_kind != "none":
            x = self.ln_final(x)
        return self.lm_head(x)


def build_model(config: dict, *, device=None, dtype=None) -> TransformerLM:
    """Build a model from either a full run config or its ``model`` section."""
    spec = config.get("model", config)
    return TransformerLM(**spec, device=device, dtype=dtype)

