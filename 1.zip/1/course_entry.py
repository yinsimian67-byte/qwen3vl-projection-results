"""学生实现三个课程接口；本文件不提供训练或模型实现。"""
import argparse
import json
from pathlib import Path


def train(config: dict, run_dir: str, resume: str | None = None):
    """从零训练或恢复；支持ranked/experiment/smoke，保存实际配置和CSV日志。"""
    raise NotImplementedError("请实现训练入口")


def load_model(checkpoint: str, config: dict):
    """接受纯评分权重或完整checkpoint；返回自己的模型，logits为[B,T,vocab]。"""
    raise NotImplementedError("请实现模型加载与前向接口")


def export(checkpoint: str, output: str):
    """ranked/smoke均导出CPU连续紧凑FP32标准state_dict；不可平均checkpoints。"""
    raise NotImplementedError("请实现权重导出接口")


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="action", required=True)
    training = sub.add_parser("train")
    training.add_argument("--config", required=True)
    training.add_argument("--run-dir", required=True)
    training.add_argument("--resume")
    exporting = sub.add_parser("export")
    exporting.add_argument("--checkpoint", required=True)
    exporting.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.action == "train":
        train(json.loads(Path(args.config).read_text()), args.run_dir, args.resume)
    else:
        export(args.checkpoint, args.output)


if __name__ == "__main__":
    main()
